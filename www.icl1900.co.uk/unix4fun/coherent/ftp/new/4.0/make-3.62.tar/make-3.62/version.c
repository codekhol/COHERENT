char *version_string = "3.62.18";

/*
  Local variables:
  version-control: never
  End:
 */
