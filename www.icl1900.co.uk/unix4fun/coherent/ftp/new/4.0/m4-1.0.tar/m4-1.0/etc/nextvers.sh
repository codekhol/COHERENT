#!/bin/sh
rlog -h "$1" 2>/dev/null | awk -F: '$1 == "head" {
	n = split($2, x, ".");
	x[n]++;
	printf("%d", x[1]);
	for (i = 2; i <= n; i++)
		printf(".%d", x[i])
}'
