/*
 * sample program to show compiler operation
 */
main()
{
	printf("Hello world!\n");
}
