/*
 * print out the integers from 1 to 10 along with their squares.
 */
main()
{
	int i;

	for (i=1; i<11; i++)
		printf("%2d\t%4d\n", i, i*i);
}
