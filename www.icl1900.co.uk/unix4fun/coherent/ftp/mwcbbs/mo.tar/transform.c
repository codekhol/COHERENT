/* A.Fongen's "Mailorg" project - rmail compatible mail user interface.

   Module TRANSFORM - customized address rewriting takes place here.

   Current version: 21.09.90
*/

#include <string.h>
#include <stdio.h>

extern char uucpname[];		/* Read into memory by mo.c */
Transform(addr)
char *addr;
{
	char buffer[100];

/* Local received mail is prefixed with "uucpname!" (from file /etc/uucpname).
   If this is the case, remove the "uucpname!". Mail sent locally (call from
   create_mail to local addressees) will have a "pure" form without 
   "@" or "!". Mail sent
   as aliases is also treated as local (expansion has not taken place yet,
   so the alias file must contain the full address. Otherwise, prefix addresses
   with naggum! (by mail feeder).

*/
#ifdef DEBUG
	printf(".%s.%s.\n",uucpname,addr); 
#endif
	if (strpbrk(addr,"!@") != NULL) {
#ifdef DEBUG
		printf("%x %x %x\n",addr,uucpname,strstr(addr,uucpname));
#endif
		if (strstr(addr,uucpname) == addr) {
#ifdef DEBUG
			printf(".%s.%s.%s\n",addr,strchr(addr,"!"),uucpname);
#endif
			strcpy(buffer,strchr(addr,'!')+1);
			strcpy(addr,buffer);
		} else {
			strcpy(buffer,"naggum!");
			strcat(buffer,addr);
			strcpy(addr,buffer);
		}
	}
}
