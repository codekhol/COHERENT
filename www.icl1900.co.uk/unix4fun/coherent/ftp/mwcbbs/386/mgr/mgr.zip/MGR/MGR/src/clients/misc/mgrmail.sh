#!/bin/sh
while true
do
	mgrmail
done
