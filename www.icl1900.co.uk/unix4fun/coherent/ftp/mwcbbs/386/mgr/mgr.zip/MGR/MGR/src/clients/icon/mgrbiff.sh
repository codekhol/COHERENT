#!/bin/sh
while true
do
	mgrbiff
done
