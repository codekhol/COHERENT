#include "f2c.h"

double r_imag(z)
complex *z;
{
return(z->i);
}
