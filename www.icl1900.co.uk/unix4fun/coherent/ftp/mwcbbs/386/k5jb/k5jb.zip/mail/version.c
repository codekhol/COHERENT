/* version control information */
char version[]  = "Bdale's Mailer v3.3.1j 920927 (K5JB)";
