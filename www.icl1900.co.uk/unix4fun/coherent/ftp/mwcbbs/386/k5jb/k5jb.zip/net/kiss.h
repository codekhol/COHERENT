/* KISS TNC control */
#define	KISS_DATA	0

