/*	SCCS Id: @(#)date.h	3.0	88/11/20 */

const char datestring[] = "Mon Jan  4 12:22:42 1993";
